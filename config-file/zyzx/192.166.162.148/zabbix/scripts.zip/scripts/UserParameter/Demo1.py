





# coding: utf-8
import sys
import json
import requests

url = (sys.argv[1])
print url
